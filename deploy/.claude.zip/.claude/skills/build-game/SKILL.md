---
name: build-game
description: Full build cycle — architect designs, scripter codes, world-builder creates environment. Use to start building or add major features.
user-invocable: true
context: fork
---

# /build-game

Runs the full build pipeline for the Roblox game through MCP.

## Usage
```
/build-game
/build-game [specific feature to build]
```

## Pipeline

### Step 1: Check Current State
Before building, inspect what already exists in Studio:
```
mcp__robloxstudio__get_project_structure
  maxDepth: 5
```
This determines whether we're starting fresh or adding to an existing game.

### Step 2: Architecture
Call the **roblox-architect** subagent:
- If first build: design the entire game
- If adding a feature: design just that feature within existing architecture
- Architect must account for MCP capabilities (primitives, no custom meshes)

Wait for architecture document output.

### Step 3: Code
Call the **luau-scripter** subagent with the architecture:
- Create folder structure first (Modules, RemoteEvents)
- Create all scripts using `create_object` + `set_script_source`
- Create RemoteEvents using `mass_create_objects`
- Verify with `get_project_structure(scriptsOnly=true)`

### Step 4: World
Call the **world-builder** subagent with the architecture:
- Set up Lighting + Atmosphere + PostProcessing
- Build terrain/rooms using `mass_create_objects_with_properties`
- Add lights, effects, details
- Create UI elements in StarterGui
- Tag interactive objects, set attributes
- Verify part count with `get_project_structure`

### Step 5: Verify
After both agents finish:
- `get_project_structure(maxDepth=10)` — full structure check
- `get_project_structure(scriptsOnly=true)` — all scripts present
- Spot-check a few scripts with `get_script_source`

### Step 6: Report
Return summary of what was created:
```
BUILD COMPLETE

Scripts: X created (Y total lines)
Parts: X created
UI Elements: X
RemoteEvents: X
Tags: X applied
Part Count: X (mobile safe: YES/NO)

Ready for: /test-game
```
