---
name: play-game
description: Claude visually plays the game using screenshots and keyboard/mouse actions. Requires VPS with Roblox Studio running.
user-invocable: true
context: fork
agent: computer-player
---

# /play-game

Launches a visual play session. The computer-player subagent takes screenshots, analyzes them, and performs actions.

## Prerequisites
- VPS must be running with Roblox Studio open
- screenshot.py and action.py must be in /app/vps/
- Game must be built (run /build-game first)

## What Happens
1. computer-player presses F5 to enter Play mode
2. Takes a screenshot to verify game loaded
3. Play loop (20-50 iterations):
   - Take screenshot
   - Analyze what's on screen (Claude is multimodal)
   - Decide action (move, click, jump, interact)
   - Execute via action.py
   - Brief pause
4. Press Escape/F5 to exit Play mode
5. Generate play session report

## Output
Play session report with:
- What was seen (visual description of the game)
- What was done (actions taken)
- Issues found (visual bugs, gameplay problems, UX issues)
- Overall impression (is this fun? would a player enjoy it?)

## Note
This skill only works on VPS with display access. For local testing, manually play the game in Studio and report observations.
